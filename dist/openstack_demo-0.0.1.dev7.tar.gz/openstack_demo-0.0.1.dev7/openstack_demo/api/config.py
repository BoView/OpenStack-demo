app = {
    'root': 'openstack_demo.api.controllers.root.RootController',
    'modules': ['openstack_demo.api'],
    'debug': False,
}